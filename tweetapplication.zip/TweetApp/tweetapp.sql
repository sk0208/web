create database tweetapp;


use tweetapp;

create table user (
user_id int auto_increment primary key,
email_id varchar(20) not null unique,
password varchar(10) not null,
status varchar(10));

select * from user;


create table tweet(
tweet_id int auto_increment primary key,
content varchar(100) not null,
user_id int,
foreign key(user_id) references user(user_id) 
);

select * from tweet;

