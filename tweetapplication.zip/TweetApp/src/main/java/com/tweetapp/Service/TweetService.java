package com.tweetapp.Service;

import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

import com.tweetapp.DAO.TweetDAO;
import com.tweetapp.DAO.TweetDAOImpl;
import com.tweetapp.model.Tweet;
import com.tweetapp.model.User;

public class TweetService {
	
	private TweetDAO tweetdao = new TweetDAOImpl();
	
	public void postTweet(User user,String content) throws SQLException
	{
		Tweet tweet = new Tweet();
		tweet.setContent(content);
		tweet.setUser_id(user.getUser_id());
		
		tweetdao.addTweet(tweet);
	}

	public List<Tweet> viewUserTweets(User user) throws SQLException {
		
		List<Tweet> allTweets = tweetdao.getAllTweets();
		List<Tweet> allUserTweets = allTweets.stream().filter(p->p.getUser_id()==user.getUser_id()).collect(Collectors.toList());
		return allUserTweets;
	}

	public List<Tweet> viewAllTweets() throws SQLException {
		List<Tweet> allTweets = tweetdao.getAllTweets();
		return allTweets;
	}
	
	
	
}
