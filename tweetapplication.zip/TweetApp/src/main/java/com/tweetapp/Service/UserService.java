package com.tweetapp.Service;

import java.sql.SQLException;
import java.util.List;

import com.tweetapp.DAO.UserDAO;
import com.tweetapp.DAO.UserDAOImpl;
import com.tweetapp.model.User;

public class UserService {
	
	private UserDAO userdao = new UserDAOImpl();
	
	public void registerUser(String email,String password) throws SQLException
	{	
		User user = new User();
		user.setEmailId(email);
		user.setPassword(password);
		user.setStatus("Inactive");
		
		int id =userdao.addUser(user);
	}
	
	public User loginUser(String email,String password) throws SQLException
	{
		User user = userdao.getUser(email);
		return user;
	}
	
	public void forgotPassword(User user) throws SQLException
	{
		userdao.updateUser(user);
	}
	
	public User getUser(String email) throws SQLException
	{
		User user = userdao.getUser(email);
		return user;
	}
	
	public void updateStatus(User user) throws SQLException
	{
		userdao.updateStatus(user);
	}
	
	public String getUserEmail(int user_id) throws SQLException
	{
		return userdao.getUserById(user_id);
	}
	
	public List<User> getAll() throws SQLException
	{
		return userdao.getAll();
	}
	
}
