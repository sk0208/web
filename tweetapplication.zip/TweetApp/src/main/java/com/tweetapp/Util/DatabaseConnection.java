package com.tweetapp.Util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
  
public class DatabaseConnection {
  
    private static Connection con = null;
  
    static
    {
        String DBurl = "jdbc:mysql://localhost:3306/tweetapp";
        String username = "root";
        String password = "pass@word1";
        try {
            con = DriverManager.getConnection(DBurl, username, password);
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static Connection getConnection()
    {
        return con;
    }
}
