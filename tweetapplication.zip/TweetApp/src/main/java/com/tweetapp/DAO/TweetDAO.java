package com.tweetapp.DAO;

import java.sql.SQLException;
import java.util.List;

import com.tweetapp.model.Tweet;



public interface TweetDAO {
	
	public int addTweet(Tweet tweet) throws SQLException;
	
	public List<Tweet> getAllTweets() throws SQLException;

}
