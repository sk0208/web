package com.tweetapp.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.tweetapp.Util.DatabaseConnection;
import com.tweetapp.model.Tweet;
import com.tweetapp.model.User;

public class TweetDAOImpl implements TweetDAO{

	static Connection conn = DatabaseConnection.getConnection(); 
	
	@Override
	public int addTweet(Tweet tweet) throws SQLException {
		
		String query = "insert into tweet(content,user_id) values(?,?)";
		
		PreparedStatement ps = conn.prepareStatement(query);
		ps.setString(1, tweet.getContent());
		ps.setInt(2, tweet.getUser_id());
		
		int i = ps.executeUpdate();
		
		return i;
	}

	@Override
	public List<Tweet> getAllTweets() throws SQLException {
		
		List<Tweet> tweets = new ArrayList<>();
		
		String query = "select * from tweet";
		
		PreparedStatement ps = conn.prepareStatement(query);
		
		ResultSet rs = ps.executeQuery();
		
		while(rs.next())
		{
			Tweet tweet = new Tweet();
			tweet.setTweetId(rs.getInt("tweet_id"));
			tweet.setContent(rs.getString("content"));
			tweet.setUser_id(rs.getInt("user_id"));
			
			tweets.add(tweet);
		}
		
		return tweets;
	}

}
