package com.tweetapp.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.tweetapp.Util.DatabaseConnection;
import com.tweetapp.model.User;

public class UserDAOImpl implements UserDAO{

	static Connection conn = DatabaseConnection.getConnection();
	
	@Override
	public int addUser(User user) throws SQLException {
		String query = "insert into user(email_id,password,status) values(?,?,?)";
		
		PreparedStatement statement = conn.prepareStatement(query);

		statement.setString(1,user.getEmailId());
		statement.setString(2,user.getPassword());
		statement.setString(3,user.getStatus());
		
		int userId = statement.executeUpdate();
	
		return userId;
	}

	@Override
	public User getUser(String username) throws SQLException {
		
		String query = "select * from user where email_id = ?";
		
		PreparedStatement statement = conn.prepareStatement(query);
		statement.setString(1,username);
		
		ResultSet rs = statement.executeQuery();
		
		User user = new User();
		
		boolean flag = false;
		
		while(rs.next())
		{
			flag = true;
			
			user.setUser_id(rs.getInt("user_id"));
			user.setEmailId(rs.getString("email_id"));
			user.setPassword(rs.getString("password"));
			user.setStatus(rs.getString("status"));
		}
		
		if(flag)
			return user;
		else
			return null;
		
		
	}

	@Override
	public void updateUser(User user) throws SQLException {
		
		String query = "update user set password = ? where email_id = ?";
		
		PreparedStatement statement = conn.prepareStatement(query);
		statement.setString(1, user.getPassword());
		statement.setString(2, user.getEmailId());
		
		statement.executeUpdate();
	}

	@Override
	public void updateStatus(User user) throws SQLException {
		String query = "update user set status = ? where email_id = ?";
		
		PreparedStatement statement = conn.prepareStatement(query);
		statement.setString(1, user.getStatus());
		statement.setString(2, user.getEmailId());		
		statement.executeUpdate();
		
	}

	@Override
	public String getUserById(int id) throws SQLException {
		
		String email=null;
		
		String query = "select email_id from user where user_id = ?";
		
		PreparedStatement statement = conn.prepareStatement(query);
		statement.setInt(1, id);
		
		ResultSet rs = statement.executeQuery();
		
		while(rs.next())
		{
			email = rs.getString("email_id");
		}
		
		return email;
	}

	@Override
	public List<User> getAll() throws SQLException {
		
		List<User> users = new ArrayList<>();
		String query = "select * from user";
		PreparedStatement ps = conn.prepareStatement(query);
		
		ResultSet rs = ps.executeQuery();
		while(rs.next())
		{
			User user = new User();
			user.setEmailId(rs.getString("email_id"));
			user.setPassword(rs.getString("password"));
			user.setUser_id(rs.getInt("user_id"));
			user.setStatus(rs.getString("status"));
			
			users.add(user);
		}
		
		return users;
	}
	
	

}
