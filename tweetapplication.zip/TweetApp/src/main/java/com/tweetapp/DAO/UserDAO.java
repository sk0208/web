package com.tweetapp.DAO;

import java.sql.SQLException;
import java.util.List;

import com.tweetapp.model.User;

public interface UserDAO {
	
	//used while register
	public int addUser(User user) throws SQLException; // this should throw custom exception like something went wrong like that
	
	//used while login
	public User getUser(String username) throws SQLException; //this should throw custom User Not Found Exception
	
	//used while reset password
	public void updateUser(User user) throws SQLException; // this should throw custom exception like something went wrong like that
	
	public void updateStatus(User user) throws SQLException;
	
	public String getUserById(int id) throws SQLException;
	
	public List<User> getAll() throws SQLException;
	
}
