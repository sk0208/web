package com.tweetapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class TweetAppApplication {
	
	public static void main(String[] args) throws Exception {
		SpringApplication.run(TweetAppApplication.class, args);
		//TweetAppApplication tw = new TweetAppApplication();
		//tw.service.showMenu();
	}

}
