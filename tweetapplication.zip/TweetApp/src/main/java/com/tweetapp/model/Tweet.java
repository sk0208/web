package com.tweetapp.model;


public class Tweet {
	private int tweetId;
	
	private String content;

	private int user_id;

	public int getTweetId() {
		return tweetId;
	}

	public void setTweetId(int i) {
		this.tweetId = i;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	
	
	@Override
	public String toString() {
		return "Tweet [tweetId=" + tweetId + ", content=" + content + ", user=" + user_id + "]";
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	
}
