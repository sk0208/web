package com.tweetapp.model;


public class User {
	
	private int user_id;
	private String emailId;
	private String password;
	private String status;
	
//	public User(String emailId,String password,String status)
//	{
//		this.emailId = emailId;
//		this.password = password;
//		this.status = status;
//	}
//	
	
	public void setUser_id(int id)
	{
		this.user_id=id;
	}
	
	public void setEmailId(String emailId)
	{
		this.emailId = emailId;
	}
	
	public void setPassword(String password)
	{
		this.password = password;
	}
	
	public void setStatus(String status)
	{
		this.status = status;
	}
	
	public int getUser_id()
	{
		return this.user_id;
	}
	
	public String getEmailId()
	{
		return this.emailId;
	}
	
	public String getPassword()
	{
		return this.password;
	}
	
	public String getStatus()
	{
		return this.status;
	}
	
	@Override
    public String toString()
    {
        return "User [user_id =" + this.user_id + ", email id =" + this.emailId + ", password =" + this.password + "]";
    }
}
