package com.tweetapp;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.tweetapp.Service.TweetService;
import com.tweetapp.Service.UserService;
import com.tweetapp.model.Tweet;
import com.tweetapp.model.User;
public class DriverCode {
		
	public static void main(String args[]) throws SQLException
	{
		UserService userService = new UserService();
		Scanner sc = new Scanner(System.in);
		DriverCode dc = new DriverCode();
		System.out.println("Hi, Welcome to TweetApp!");
		System.out.println("Please choose any of the options below");
		String status = "Inactive";
		int ch = 1;
		User user = new User();
		while(status == "Inactive")
		{
			System.out.println("1.Register\n2.Login\n3.Forgot Password");
			ch = sc.nextInt();
			switch(ch)
			{
				case 1: dc.register(userService);
						break;
				
				case 2: user = dc.login(userService);
						if(user != null)
						{
							status = "Active";
							user.setStatus("Active");
							userService.updateStatus(user);
							dc.showTweetMenu(user);
						}
						else
						{
							System.out.println("User Not found, please login again with valid credentials");
						}
						break;
				
				case 3:dc.forgotpassword();
						break;
				
				default : System.out.println("Invalid choice");
						break;
			}
		}
		
	}
	
	public void showTweetMenu(User user) throws SQLException
	{
		DriverCode dc = new DriverCode();
		Scanner sc = new Scanner(System.in);
		String status = user.getStatus();
		int ch = 0;
		System.out.println("Successfully Logged in!");
		while(status == "Active" && ch != 6)
		{
			System.out.println("1.Post a tweet\n2.View my tweets\n3.View all tweets\n4.View all users\n5.Reset Password\n6.Logout");
			ch = sc.nextInt();
			switch(ch)
			{
				case 1: dc.post(user);
						break;
				
				case 2: dc.viewUserTweets(user);
						break;
						
				case 3: dc.viewAllTweets();
						break;
						
				case 4: dc.viewAllUsers();
						break;
						
				case 5: dc.forgotpassword();
						break;
						
				case 6: dc.logout(user);
						break;
						
				default:System.out.println("Invalid choice");
						break;
			}
		}
	}
	
	public void register(UserService us) throws SQLException
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("User Registration:\nPlease enter email Id:");
		String email = sc.nextLine();
		System.out.println("Please enter password");
		String password = sc.nextLine();
		
		us.registerUser(email,password);
		
		System.out.println("New User "+email+" Registered!\n"+"Please Login\n");
		//sc.close();
	}
	
	public User login(UserService us) throws SQLException
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("User Login:\nPlease enter email Id:");
		String email = sc.nextLine();
		System.out.println("Please enter password");
		String password = sc.nextLine();
		
		User user = us.loginUser(email, password);
		return user;
	
		
	}
	
	public void forgotpassword() throws SQLException
	{
		UserService us = new UserService();
		Scanner sc = new Scanner(System.in);
		System.out.println("Lets reset your password!!");
		System.out.println("Please enter your email id:");
		String email = sc.nextLine();
		User user = us.getUser(email);
		if(user == null)
		{
			System.out.println("email does not exist please try again");
		}
		else
		{
			System.out.println("Enter new Password:");
			String newPass = sc.nextLine();
			user.setPassword(newPass);
			us.forgotPassword(user);
			System.out.println("Password reset is successfull!!\n Please login again");
		}
	}
	
	public void post(User user) throws SQLException
	{
		Scanner sc = new Scanner(System.in);
		TweetService ts = new TweetService();
		
		System.out.println("Post Tweet!");
		System.out.println("Enter content that you want to post:");
		String content = sc.nextLine();
		
		ts.postTweet(user,content);
		
		System.out.println("Posted '"+content+"' by "+user.getEmailId()+"\n\n");
	}
	
	public void viewUserTweets(User user) throws SQLException
	{
		TweetService ts = new TweetService();
		List<Tweet> tweets = ts.viewUserTweets(user);
		
		System.out.println("Tweets of "+user.getEmailId());
		
		tweets.stream().map(p->p.getContent()).forEach(System.out::println);
	}
	
	public void viewAllTweets() throws SQLException
	{
		TweetService ts = new TweetService();
		UserService us = new UserService();
		
		List<Tweet> tweets = ts.viewAllTweets();
		
		for(Tweet tweet : tweets)
		{
			String email = us.getUserEmail(tweet.getUser_id());
			System.out.println("Tweet By "+email+" :"+tweet.getContent());
		}
	}
	
	public void viewAllUsers() throws SQLException
	{
		UserService us = new UserService();
		List<User> users = us.getAll();
		
		users.stream().map(p->p.getUser_id()+" email id = "+p.getEmailId()+" status = "+p.getStatus()).forEach(System.out::println);
	}
	
	public void resetPassword(User user)
	{
		System.out.println("Reset Password");
	}
	
	public void logout(User user) throws SQLException
	{
		UserService userService = new UserService();
		user.setStatus("Inactive");
		userService.updateStatus(user);
		System.out.println("Successfully logged out\nThanks for using Tweet App :)");
	}
}
